#!/usr/bin/env python3

from PLAgent import PLAgent

filename = input()
# Spawn an agent
agent = PLAgent(filename)

method = input()
agent.interpret(method)
