from collections import deque
from HornClause import HornClause
import time
import resource


def fc_entail(kb, query, symbols):
    def fc(kb, query, count, agenda, inferred):
        while agenda:
            p = agenda.popleft()
            if p == query:
                return True
            if not inferred[p]:
                inferred[p] = True
                for clause in kb:
                    if p in clause.head():
                        count[clause] -= 1
                        if count[clause] == 0:
                            agenda.append(clause.tail())

    t0 = time.time()
    count = {}
    inferred = {}
    agenda = deque([])
    horn = set()

    for clause in kb:
        if isinstance(clause, HornClause):
            horn.add(clause)
            count[clause] = len(clause.head())
            for prem in clause.head():
                inferred[prem] = False
            inferred[clause.tail()] = False
        else:
            inferred[clause] = False
            agenda.append(clause)

    res = fc(horn, query, count, agenda, inferred)
    t1 = time.time()
    mem = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss


    if res:
        out = 'YES: '
        for sym in inferred.keys():
            if inferred[sym]:
                out += str(sym)
                out += ', '
        out += str(query)
        print(out)
    else:
        print('NO')
    print('Runtime: ' + str(t1 - t0))
    print('Memory: ' + str(mem))
