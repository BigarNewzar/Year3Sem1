 

public enum Status {
	Clean,
	Dirty,
	Nil
};
