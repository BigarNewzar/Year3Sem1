 

public enum Action {
	Up,
	Down,
	Left,
	Right,
	Suck,
	NoOp
};
