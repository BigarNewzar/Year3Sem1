 

public abstract class Environment {

}
