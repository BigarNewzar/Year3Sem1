 

public interface Percept {

}
